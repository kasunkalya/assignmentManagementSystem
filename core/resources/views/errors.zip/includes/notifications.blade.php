<li>
    <a href="javascript:;" data-toggle="dropdown">
      <i class="fa fa-bell-o"></i>
      <div class="status bg-danger border-danger animated bounce"></div>
    </a>
    <ul class="dropdown-menu notifications">
      <li class="notifications-header">
        <p class="text-muted small">You have 3 new messages</p>
      </li>
      <li>
        <ul class="notifications-list">
          <li>
            <a href="javascript:;">
              <span class="pull-left mt2 mr15">
                <img src="{{asset('assets/sammy_new/images/avatar.jpg')}}" class="avatar avatar-xs img-circle" alt="">
              </span>
              <div class="overflow-hidden">
                <span>Sean launched a new application</span>
                <span class="time">2 seconds ago</span>
              </div>
            </a>
          </li>
        </ul>
      </li>
      <li class="notifications-footer">
        <a href="javascript:;">See all messages</a>
      </li>
    </ul>
</li>