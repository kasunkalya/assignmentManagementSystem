<ul class="nav">
@if(isset($menu))
	{!!$menu!!}
@endif
</ul>
